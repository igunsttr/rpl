from django.db import models
class Jurusan(models.Model):
    no=models.AutoField(auto_created = True, primary_key=True, serialize=True)
    nama=models.CharField(max_length=100, blank=False, null=False)
    def __str__(self):
        return self.nama
class Mahasiswa(models.Model):
    no=models.AutoField(auto_created = True, primary_key=True, serialize=True)
    nama=models.CharField(max_length=100, blank=False, null=False)
    nim=models.CharField(max_length=12, blank=False, null=False) 
    alamat=models.CharField(max_length=100, blank=False, null=False)
    telepon=models.CharField(max_length=12, blank=False, null=False)
    email=models.EmailField(max_length=100, blank=False, null=False)
    status=models.BooleanField(default=0)
    id_jurusan=models.ForeignKey(Jurusan, on_delete=models.CASCADE, blank=True, null=True)
    def __str__(self):
        return self.nama
    class Meta:
        verbose_name_plural = "Mahasiswa tanpa S"

class Dosen(models.Model):
    no=models.AutoField(auto_created = True, primary_key=True, serialize=True)
    nidn=models.CharField(max_length=100, blank=False, null=False)
    nama=models.CharField(max_length=100, blank=False, null=False)
    id_jurusan=models.ForeignKey(Jurusan, on_delete=models.CASCADE, blank=True, null=True)
    def __str__(self):
        return self.nama
class Matkul(models.Model):
    no = models.AutoField(auto_created = True, primary_key=True, serialize=True)
    nama =models.CharField(max_length=100, blank=False, null=False)
    id_dosen =models.ForeignKey(Dosen, on_delete=models.CASCADE, blank=True, null=True)
    semester=models.CharField(max_length=1, blank=False, null=False)
    tahun_ajaran=models.CharField(max_length=4,blank=False, null=False)
    ruangan=models.CharField(max_length=20, blank=False, null=False)
    waktu=models.DateTimeField(auto_now_add=True)
    hari = models.CharField(max_length=10, blank=False, null=False)
    def __str__(self):
        return self.nama
class Kaprodi(models.Model):
    no = models.AutoField(auto_created = True, primary_key=True, serialize=True)
    nama =models.CharField(max_length=100, blank=False, null=False)
    id_dosen=models.ForeignKey(Dosen, on_delete=models.CASCADE, blank=True, null=True)
    id_jurusan=models.ForeignKey(Jurusan, on_delete=models.CASCADE, blank=True, null=True)
    def __str__(self):
        return self.nama

class Beritaacara(models.Model):
    no=models.AutoField(auto_created = True, primary_key=True, serialize=True)
    sesi=models.CharField(max_length=100, blank=False, null=False)
    materi=models.CharField(max_length=100, blank=False, null=False)
    waktu=models.DateTimeField(auto_now_add=True)
    materi_diberikan=models.CharField(max_length=100, blank=False, null=False)
    alasan=models.CharField(max_length=100, blank=False, null=False)
    tanggal=models.DateField(blank=False, null=False)
    sifat=models.BooleanField(default=0)
    approval1=models.BooleanField(default=0)
    approvalmhs=models.BooleanField(default=0)
    approvalkaprodi=models.BooleanField(default=0)
    id_mhs = models.ForeignKey(Mahasiswa, on_delete=models.CASCADE, blank=True, null=True)
    id_dosen = models.ForeignKey(Dosen, on_delete=models.CASCADE, blank=True, null=True)
    id_kaprodi = models.ForeignKey(Kaprodi, on_delete=models.CASCADE, blank=True, null=True)
    id_matkul = models.ForeignKey(Matkul, on_delete=models.CASCADE, blank=True, null=True)
    id_jurusan = models.ForeignKey(Jurusan, on_delete=models.CASCADE, blank=True, null=True)
    def __str__(self):
        return self.sesi