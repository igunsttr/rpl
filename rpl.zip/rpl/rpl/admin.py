from django.contrib import admin

admin.site.site_header = 'Halaman Administrasi'

from .models import Mahasiswa, Jurusan, Beritaacara, Dosen, Matkul, Kaprodi

admin.site.register(Mahasiswa)
admin.site.register(Jurusan)

class AdminBeritaacara(admin.ModelAdmin):

    mhs_field = ('materi_diberikan','sesi','materi','materi_diberikan',
                       'waktu','alasan','tanggal','sifat',
                       'approval1','id_mhs','id_dosen',
                       'id_kaprodi','id_matkul','id_jurusan','approvalkaprodi')
    dosen_field = ('approvalmhs', 'approvalkaprodi')
    kaprodi_field=('materi_diberikan','sesi','materi','materi_diberikan',
                       'waktu','alasan','tanggal','sifat',
                       'approval1','id_mhs','id_dosen',
                       'id_kaprodi','id_matkul','id_jurusan','approvalmhs')
    admin_field=('')

    def get_readonly_fields(self, request, obj=None):
        
        if request.user.groups.filter(name='kaprodi').exists():
            return self.kaprodi_field
        elif request.user.groups.filter(name='dosen').exists():
            return self.dosen_field
        elif request.user.groups.filter(name='admin').exists():
            return self.admin_field
        else:
            return self.mhs_field
        return super().get_fieldsets(request, obj=obj)
    
admin.site.register(Beritaacara, AdminBeritaacara)

admin.site.register(Dosen)
admin.site.register(Matkul)
admin.site.register(Kaprodi)
